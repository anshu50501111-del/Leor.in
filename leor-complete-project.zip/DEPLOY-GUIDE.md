# LEOR Website — Deploy Guide (Hindi)
## Vercel pe FREE mein live karo — 10 minute mein!

---

## STEP 1 — GitHub pe daalo
1. github.com pe free account banao
2. New Repository banao — naam: "leor-website"
3. Ye saari files upload karo:
   - public/index.html
   - api/create-order.js
   - api/verify-order.js
   - package.json
   - vercel.json

---

## STEP 2 — Vercel pe deploy karo
1. vercel.com pe jaao → GitHub se login karo
2. "New Project" → Apna leor-website repo select karo
3. Deploy dabao → 2 minute mein live ho jayega!

---

## STEP 3 — Cashfree API Keys daalo (IMPORTANT!)
Vercel Dashboard mein:
1. Apna project kholo
2. Settings → Environment Variables
3. Ye 2 variables add karo:

   Name: CASHFREE_APP_ID
   Value: [Tumhara App ID — Cashfree dashboard se lo]

   Name: CASHFREE_SECRET_KEY
   Value: [Tumhari Secret Key — Cashfree dashboard se lo]

4. Redeploy karo

---

## STEP 4 — Cashfree mein domain whitelist karo
1. sandbox.cashfree.com pe login karo
2. Developer → Webhooks/Settings
3. Apna Vercel URL add karo: https://leor-website.vercel.app

---

## Test Cards (Sandbox Mode mein)
- Card: 4111 1111 1111 1111
- Expiry: 12/26
- CVV: 123
- OTP: 123456

UPI Test: success@cashfree

---

## ⚠️ ZAROORI — Keys ki safety
- .env file kabhi GitHub pe mat daalo
- Sirf Vercel Environment Variables use karo
- Purani share ki hui keys ABHI regenerate karo!

---

## Production ke liye (Real payments)
1. Cashfree dashboard pe KYC complete karo
2. Live keys lo
3. api/create-order.js mein URL change karo:
   sandbox.cashfree.com → api.cashfree.com
4. index.html mein CF_MODE: 'sandbox' → 'production'
