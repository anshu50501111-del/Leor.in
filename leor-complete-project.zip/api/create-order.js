// api/create-order.js — Vercel Serverless Function
// Secret key SIRF yahaan hai — browser tak kabhi nahi jaati

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { amount, customerName, customerPhone, customerEmail, orderId } = req.body;

    // Validation
    if (!amount || !customerPhone) {
      return res.status(400).json({ error: 'Amount aur phone number zaroori hai' });
    }

    const orderPayload = {
      order_id: orderId || `LEOR_${Date.now()}`,
      order_amount: parseFloat(amount),
      order_currency: 'INR',
      customer_details: {
        customer_id: `cust_${Date.now()}`,
        customer_name: customerName || 'LEOR Customer',
        customer_email: customerEmail || 'customer@leor.in',
        customer_phone: customerPhone,
      },
      order_meta: {
        return_url: `${req.headers.origin || 'https://your-domain.vercel.app'}/payment-success?order_id={order_id}`,
        notify_url: `${req.headers.origin || 'https://your-domain.vercel.app'}/api/webhook`,
      },
      order_note: 'LEOR Handmade Art Order',
    };

    // Cashfree API call — SECRET KEY sirf yahaan, environment variable mein
    const response = await fetch('https://sandbox.cashfree.com/pg/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-client-id': process.env.CASHFREE_APP_ID,         // .env file mein
        'x-client-secret': process.env.CASHFREE_SECRET_KEY, // .env file mein
        'x-api-version': '2023-08-01',
      },
      body: JSON.stringify(orderPayload),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Cashfree error:', data);
      return res.status(400).json({ error: data.message || 'Order create karne mein error' });
    }

    // Sirf payment_session_id frontend ko bhejo — secret key nahi!
    return res.status(200).json({
      payment_session_id: data.payment_session_id,
      order_id: data.order_id,
      order_status: data.order_status,
    });

  } catch (error) {
    console.error('Server error:', error);
    return res.status(500).json({ error: 'Server error aaya, dobara try karo' });
  }
}
