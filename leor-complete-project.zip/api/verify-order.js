// api/verify-order.js — Payment verify karo order complete hone ke baad

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const { order_id } = req.body;
    if (!order_id) return res.status(400).json({ error: 'order_id zaroori hai' });

    const response = await fetch(`https://sandbox.cashfree.com/pg/orders/${order_id}`, {
      method: 'GET',
      headers: {
        'x-client-id': process.env.CASHFREE_APP_ID,
        'x-client-secret': process.env.CASHFREE_SECRET_KEY,
        'x-api-version': '2023-08-01',
      },
    });

    const data = await response.json();

    return res.status(200).json({
      order_id: data.order_id,
      order_status: data.order_status,   // PAID | ACTIVE | EXPIRED
      order_amount: data.order_amount,
      payment_session_id: data.payment_session_id,
    });

  } catch (error) {
    return res.status(500).json({ error: 'Verify karne mein error' });
  }
}
